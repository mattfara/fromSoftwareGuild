/*
	Select all columns for the product with the name Queso Cabrales
*/

USE Northwind;
