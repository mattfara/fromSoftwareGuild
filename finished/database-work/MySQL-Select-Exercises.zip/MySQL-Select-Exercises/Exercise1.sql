/*
	Select all of the rows and columns from the Products table 
*/

USE Northwind;
