/*
	Find the average freight paid for orders 
	placed by companies in the USA
*/

USE Northwind;
