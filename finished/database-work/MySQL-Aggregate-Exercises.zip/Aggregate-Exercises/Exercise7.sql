/*
	Find the total sales by supplier 
	ordered from most to least.
*/

USE Northwind;
