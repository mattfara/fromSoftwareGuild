/*
	Get all the order information for any order where Chai was sold.
*/

USE Northwind;